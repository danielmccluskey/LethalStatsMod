#### v 1.0.0
Added global stats collection and orders.

#### v 0.9.5
Now collects stats about sold items for global challenges feature.

#### v 0.9.4
Now collects stats about collected items and mods in preparation for the launch of daily challenges.

#### v 0.9.3
Quick change in preparation for the new update coming shortly which will allow me to separate stats by game version.

#### v 0.9.2
Shortened Success message and added Events to the message for planned match timeline feature.

#### v 0.9.1
- Fix for round duration bug always being roughly 16 seconds.

#### v.0.9.0
- Initial Release for testing.

